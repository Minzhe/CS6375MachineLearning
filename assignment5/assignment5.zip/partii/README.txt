Read Me

1. The program is written in python 3, recent version of pandas, numpy and sklearn are needed.

2. The code does not generate output. To get the result, copy the code to some IDE like Jupiter notebook or rodeo, and print the corresponding result.