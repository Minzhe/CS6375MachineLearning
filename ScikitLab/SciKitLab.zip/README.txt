########################
###    ScikitLab     ###
########################

Minzhe Zhang
mxz163730

The dataset used for question2 is UCI machine learning iris datasets.
http://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data

The original code is in SciKitLab.ipynb, result is in SciKitLab.html.

I choose hidden layer size as 4, 4, 3, and the prediction accuracy is already very good, 98% in training dataset, 100% in test dataset.